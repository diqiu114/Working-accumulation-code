﻿namespace Mifare1K
{
    partial class ICODE
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ICODE));
            this.tsbtnConnect = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsICODE = new System.Windows.Forms.ToolStrip();
            this.textUID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textStatus = new System.Windows.Forms.TextBox();
            this.textData = new System.Windows.Forms.TextBox();
            this.btnInventory = new System.Windows.Forms.Button();
            this.btnLock = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.cbxBlock = new System.Windows.Forms.ComboBox();
            this.btnRead = new System.Windows.Forms.Button();
            this.btnWrite = new System.Windows.Forms.Button();
            this.tsICODE.SuspendLayout();
            this.SuspendLayout();
            // 
            // tsbtnConnect
            // 
            this.tsbtnConnect.BackColor = System.Drawing.SystemColors.Control;
            this.tsbtnConnect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbtnConnect.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnConnect.Image")));
            this.tsbtnConnect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnConnect.Name = "tsbtnConnect";
            this.tsbtnConnect.Size = new System.Drawing.Size(59, 22);
            this.tsbtnConnect.Text = "Connect";
            this.tsbtnConnect.Click += new System.EventHandler(this.tsbtnConnect_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsICODE
            // 
            this.tsICODE.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnConnect,
            this.toolStripSeparator1});
            this.tsICODE.Location = new System.Drawing.Point(0, 0);
            this.tsICODE.Name = "tsICODE";
            this.tsICODE.Size = new System.Drawing.Size(549, 25);
            this.tsICODE.TabIndex = 33;
            this.tsICODE.Text = "ICODE";
            // 
            // textUID
            // 
            this.textUID.Location = new System.Drawing.Point(95, 67);
            this.textUID.Name = "textUID";
            this.textUID.ReadOnly = true;
            this.textUID.Size = new System.Drawing.Size(271, 21);
            this.textUID.TabIndex = 34;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 15);
            this.label1.TabIndex = 35;
            this.label1.Text = "UID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(386, 170);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 15);
            this.label2.TabIndex = 36;
            this.label2.Text = "Status:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 15);
            this.label3.TabIndex = 37;
            this.label3.Text = "Data:";
            // 
            // textStatus
            // 
            this.textStatus.Location = new System.Drawing.Point(438, 167);
            this.textStatus.Name = "textStatus";
            this.textStatus.ReadOnly = true;
            this.textStatus.Size = new System.Drawing.Size(56, 21);
            this.textStatus.TabIndex = 39;
            // 
            // textData
            // 
            this.textData.Location = new System.Drawing.Point(95, 167);
            this.textData.Name = "textData";
            this.textData.Size = new System.Drawing.Size(271, 21);
            this.textData.TabIndex = 40;
            // 
            // btnInventory
            // 
            this.btnInventory.Location = new System.Drawing.Point(71, 263);
            this.btnInventory.Name = "btnInventory";
            this.btnInventory.Size = new System.Drawing.Size(94, 23);
            this.btnInventory.TabIndex = 42;
            this.btnInventory.Text = "Inventory";
            this.btnInventory.UseVisualStyleBackColor = true;
            this.btnInventory.Click += new System.EventHandler(this.btnInventory_Click);
            // 
            // btnLock
            // 
            this.btnLock.Location = new System.Drawing.Point(386, 263);
            this.btnLock.Name = "btnLock";
            this.btnLock.Size = new System.Drawing.Size(94, 23);
            this.btnLock.TabIndex = 43;
            this.btnLock.Text = "Lock";
            this.btnLock.UseVisualStyleBackColor = true;
            this.btnLock.Click += new System.EventHandler(this.btnLock_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(46, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 15);
            this.label4.TabIndex = 44;
            this.label4.Text = "Block:";
            // 
            // cbxBlock
            // 
            this.cbxBlock.FormattingEnabled = true;
            this.cbxBlock.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27"});
            this.cbxBlock.Location = new System.Drawing.Point(95, 116);
            this.cbxBlock.Name = "cbxBlock";
            this.cbxBlock.Size = new System.Drawing.Size(111, 23);
            this.cbxBlock.TabIndex = 45;
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(176, 263);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(94, 23);
            this.btnRead.TabIndex = 46;
            this.btnRead.Text = "Read";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // btnWrite
            // 
            this.btnWrite.Location = new System.Drawing.Point(281, 263);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(94, 23);
            this.btnWrite.TabIndex = 47;
            this.btnWrite.Text = "Write";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // FM1208
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(549, 347);
            this.Controls.Add(this.btnWrite);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.cbxBlock);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnLock);
            this.Controls.Add(this.btnInventory);
            this.Controls.Add(this.textData);
            this.Controls.Add(this.textStatus);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textUID);
            this.Controls.Add(this.tsICODE);
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ICODE";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ICODE";
            this.Load += new System.EventHandler(this.Mifare_1K_Load);
            this.tsICODE.ResumeLayout(false);
            this.tsICODE.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripButton tsbtnConnect;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStrip tsICODE;
        private System.Windows.Forms.TextBox textUID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textStatus;
        private System.Windows.Forms.TextBox textData;
        private System.Windows.Forms.Button btnInventory;
        private System.Windows.Forms.Button btnLock;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbxBlock;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Button btnWrite;
    }
}

