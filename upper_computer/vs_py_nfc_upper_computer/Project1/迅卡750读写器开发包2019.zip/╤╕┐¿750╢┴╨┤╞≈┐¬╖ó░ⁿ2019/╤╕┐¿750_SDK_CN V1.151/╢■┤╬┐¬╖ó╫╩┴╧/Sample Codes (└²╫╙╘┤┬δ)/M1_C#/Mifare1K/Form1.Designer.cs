﻿namespace Mifare1K
{
    partial class Mifare_1K
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mifare_1K));
            this.txtSearchPurse = new System.Windows.Forms.TextBox();
            this.btnRequest = new System.Windows.Forms.Button();
            this.btnReqIDL = new System.Windows.Forms.Button();
            this.btnHalt = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnCreditCardBalance = new System.Windows.Forms.Button();
            this.btnCreditCardDecrement = new System.Windows.Forms.Button();
            this.btnCreditCardIncrement = new System.Windows.Forms.Button();
            this.btnPurseInit = new System.Windows.Forms.Button();
            this.txtBoxPurseHex = new System.Windows.Forms.TextBox();
            this.txtPurseDec = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxPurseKey = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.rbtPurseKeyB = new System.Windows.Forms.RadioButton();
            this.rbtPurseKeyA = new System.Windows.Forms.RadioButton();
            this.cbxSubmass1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbxMass1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtInputKey2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.rbtKeyB2 = new System.Windows.Forms.RadioButton();
            this.rbtKeyA2 = new System.Windows.Forms.RadioButton();
            this.txtKeyB2 = new System.Windows.Forms.TextBox();
            this.txtKey2 = new System.Windows.Forms.TextBox();
            this.txtKeyA2 = new System.Windows.Forms.TextBox();
            this.txtDataThree2 = new System.Windows.Forms.TextBox();
            this.txtBoxDataTwo2 = new System.Windows.Forms.TextBox();
            this.txtBoxDataOne2 = new System.Windows.Forms.TextBox();
            this.btnWriteBlock2 = new System.Windows.Forms.Button();
            this.btnReadSector2 = new System.Windows.Forms.Button();
            this.cbxSubmass2 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cbxMass2 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtInputKey3 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.rbtKeyB3 = new System.Windows.Forms.RadioButton();
            this.rbtKeyA3 = new System.Windows.Forms.RadioButton();
            this.txtKeyB3 = new System.Windows.Forms.TextBox();
            this.txtKey3 = new System.Windows.Forms.TextBox();
            this.txtKeyA3 = new System.Windows.Forms.TextBox();
            this.txtDataThree3 = new System.Windows.Forms.TextBox();
            this.txtDataTwo3 = new System.Windows.Forms.TextBox();
            this.txtDataOne3 = new System.Windows.Forms.TextBox();
            this.btnWriteBlock3 = new System.Windows.Forms.Button();
            this.btnReadSector3 = new System.Windows.Forms.Button();
            this.cbxSubmass3 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cbxMass3 = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtInputKey4 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.rbtKeyB4 = new System.Windows.Forms.RadioButton();
            this.rbtKeyA4 = new System.Windows.Forms.RadioButton();
            this.txtKeyB4 = new System.Windows.Forms.TextBox();
            this.txtKey4 = new System.Windows.Forms.TextBox();
            this.txtKeyA4 = new System.Windows.Forms.TextBox();
            this.txtDataThree4 = new System.Windows.Forms.TextBox();
            this.txtDataTwo4 = new System.Windows.Forms.TextBox();
            this.txtDataOne4 = new System.Windows.Forms.TextBox();
            this.btnWriteBlock4 = new System.Windows.Forms.Button();
            this.btnReadSector4 = new System.Windows.Forms.Button();
            this.cbxSubmass4 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.cbxMass4 = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tsMifare1K = new System.Windows.Forms.ToolStrip();
            this.tsbtnConnect = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tsMifare1K.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtSearchPurse
            // 
            this.txtSearchPurse.Location = new System.Drawing.Point(12, 33);
            this.txtSearchPurse.Name = "txtSearchPurse";
            this.txtSearchPurse.Size = new System.Drawing.Size(152, 24);
            this.txtSearchPurse.TabIndex = 0;
            // 
            // btnRequest
            // 
            this.btnRequest.Location = new System.Drawing.Point(180, 32);
            this.btnRequest.Name = "btnRequest";
            this.btnRequest.Size = new System.Drawing.Size(110, 23);
            this.btnRequest.TabIndex = 1;
            this.btnRequest.Text = "Request";
            this.btnRequest.UseVisualStyleBackColor = true;
            this.btnRequest.Click += new System.EventHandler(this.btnRequest_Click);
            // 
            // btnReqIDL
            // 
            this.btnReqIDL.Location = new System.Drawing.Point(296, 32);
            this.btnReqIDL.Name = "btnReqIDL";
            this.btnReqIDL.Size = new System.Drawing.Size(110, 23);
            this.btnReqIDL.TabIndex = 2;
            this.btnReqIDL.Text = "ReqIDL";
            this.btnReqIDL.UseVisualStyleBackColor = true;
            this.btnReqIDL.Click += new System.EventHandler(this.btnReqIDL_Click);
            // 
            // btnHalt
            // 
            this.btnHalt.Location = new System.Drawing.Point(413, 32);
            this.btnHalt.Name = "btnHalt";
            this.btnHalt.Size = new System.Drawing.Size(110, 23);
            this.btnHalt.TabIndex = 3;
            this.btnHalt.Text = "Halt";
            this.btnHalt.UseVisualStyleBackColor = true;
            this.btnHalt.Click += new System.EventHandler(this.btnHalt_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnCreditCardBalance);
            this.groupBox1.Controls.Add(this.btnCreditCardDecrement);
            this.groupBox1.Controls.Add(this.btnCreditCardIncrement);
            this.groupBox1.Controls.Add(this.btnPurseInit);
            this.groupBox1.Controls.Add(this.txtBoxPurseHex);
            this.groupBox1.Controls.Add(this.txtPurseDec);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBoxPurseKey);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.rbtPurseKeyB);
            this.groupBox1.Controls.Add(this.rbtPurseKeyA);
            this.groupBox1.Controls.Add(this.cbxSubmass1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cbxMass1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 65);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(426, 242);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Purse function";
            // 
            // btnCreditCardBalance
            // 
            this.btnCreditCardBalance.Location = new System.Drawing.Point(284, 199);
            this.btnCreditCardBalance.Name = "btnCreditCardBalance";
            this.btnCreditCardBalance.Size = new System.Drawing.Size(75, 23);
            this.btnCreditCardBalance.TabIndex = 15;
            this.btnCreditCardBalance.Text = "Balance";
            this.btnCreditCardBalance.UseVisualStyleBackColor = true;
            this.btnCreditCardBalance.Click += new System.EventHandler(this.btnCreditCardBalance_Click);
            // 
            // btnCreditCardDecrement
            // 
            this.btnCreditCardDecrement.Location = new System.Drawing.Point(193, 199);
            this.btnCreditCardDecrement.Name = "btnCreditCardDecrement";
            this.btnCreditCardDecrement.Size = new System.Drawing.Size(75, 23);
            this.btnCreditCardDecrement.TabIndex = 14;
            this.btnCreditCardDecrement.Text = "Decrement";
            this.btnCreditCardDecrement.UseVisualStyleBackColor = true;
            this.btnCreditCardDecrement.Click += new System.EventHandler(this.btnCreditCardDecrement_Click);
            // 
            // btnCreditCardIncrement
            // 
            this.btnCreditCardIncrement.Location = new System.Drawing.Point(101, 199);
            this.btnCreditCardIncrement.Name = "btnCreditCardIncrement";
            this.btnCreditCardIncrement.Size = new System.Drawing.Size(75, 23);
            this.btnCreditCardIncrement.TabIndex = 13;
            this.btnCreditCardIncrement.Text = "Increment";
            this.btnCreditCardIncrement.UseVisualStyleBackColor = true;
            this.btnCreditCardIncrement.Click += new System.EventHandler(this.btnCreditCardIncrement_Click);
            // 
            // btnPurseInit
            // 
            this.btnPurseInit.Location = new System.Drawing.Point(8, 199);
            this.btnPurseInit.Name = "btnPurseInit";
            this.btnPurseInit.Size = new System.Drawing.Size(75, 23);
            this.btnPurseInit.TabIndex = 12;
            this.btnPurseInit.Text = "Initialize";
            this.btnPurseInit.UseVisualStyleBackColor = true;
            this.btnPurseInit.Click += new System.EventHandler(this.btnPurseInit_Click);
            // 
            // txtBoxPurseHex
            // 
            this.txtBoxPurseHex.Location = new System.Drawing.Point(192, 141);
            this.txtBoxPurseHex.Name = "txtBoxPurseHex";
            this.txtBoxPurseHex.Size = new System.Drawing.Size(173, 24);
            this.txtBoxPurseHex.TabIndex = 11;
            // 
            // txtPurseDec
            // 
            this.txtPurseDec.Location = new System.Drawing.Point(8, 141);
            this.txtPurseDec.Name = "txtPurseDec";
            this.txtPurseDec.Size = new System.Drawing.Size(181, 24);
            this.txtPurseDec.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(192, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 18);
            this.label5.TabIndex = 9;
            this.label5.Text = "Value(Hex)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 18);
            this.label4.TabIndex = 8;
            this.label4.Text = "Value(Dec)";
            // 
            // textBoxPurseKey
            // 
            this.textBoxPurseKey.Location = new System.Drawing.Point(178, 74);
            this.textBoxPurseKey.Name = "textBoxPurseKey";
            this.textBoxPurseKey.Size = new System.Drawing.Size(119, 24);
            this.textBoxPurseKey.TabIndex = 7;
            this.textBoxPurseKey.Text = "FFFFFFFFFFFF";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(148, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 18);
            this.label3.TabIndex = 6;
            this.label3.Text = "Key";
            // 
            // rbtPurseKeyB
            // 
            this.rbtPurseKeyB.AutoSize = true;
            this.rbtPurseKeyB.Location = new System.Drawing.Point(70, 74);
            this.rbtPurseKeyB.Name = "rbtPurseKeyB";
            this.rbtPurseKeyB.Size = new System.Drawing.Size(64, 22);
            this.rbtPurseKeyB.TabIndex = 5;
            this.rbtPurseKeyB.Text = "KeyB";
            this.rbtPurseKeyB.UseVisualStyleBackColor = true;
            // 
            // rbtPurseKeyA
            // 
            this.rbtPurseKeyA.AutoSize = true;
            this.rbtPurseKeyA.Checked = true;
            this.rbtPurseKeyA.Location = new System.Drawing.Point(8, 74);
            this.rbtPurseKeyA.Name = "rbtPurseKeyA";
            this.rbtPurseKeyA.Size = new System.Drawing.Size(63, 22);
            this.rbtPurseKeyA.TabIndex = 4;
            this.rbtPurseKeyA.TabStop = true;
            this.rbtPurseKeyA.Text = "KeyA";
            this.rbtPurseKeyA.UseVisualStyleBackColor = true;
            // 
            // cbxSubmass1
            // 
            this.cbxSubmass1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSubmass1.FormattingEnabled = true;
            this.cbxSubmass1.Items.AddRange(new object[] {
            "0",
            "1"});
            this.cbxSubmass1.Location = new System.Drawing.Point(171, 35);
            this.cbxSubmass1.MaxDropDownItems = 3;
            this.cbxSubmass1.Name = "cbxSubmass1";
            this.cbxSubmass1.Size = new System.Drawing.Size(67, 26);
            this.cbxSubmass1.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(130, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Block";
            // 
            // cbxMass1
            // 
            this.cbxMass1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxMass1.FormattingEnabled = true;
            this.cbxMass1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbxMass1.Location = new System.Drawing.Point(54, 35);
            this.cbxMass1.MaxDropDownItems = 16;
            this.cbxMass1.Name = "cbxMass1";
            this.cbxMass1.Size = new System.Drawing.Size(67, 26);
            this.cbxMass1.TabIndex = 1;
            this.cbxMass1.SelectedIndexChanged += new System.EventHandler(this.cbxMass1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sector";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.textBox6);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.comboBox2);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txtInputKey2);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.rbtKeyB2);
            this.groupBox2.Controls.Add(this.rbtKeyA2);
            this.groupBox2.Controls.Add(this.txtKeyB2);
            this.groupBox2.Controls.Add(this.txtKey2);
            this.groupBox2.Controls.Add(this.txtKeyA2);
            this.groupBox2.Controls.Add(this.txtDataThree2);
            this.groupBox2.Controls.Add(this.txtBoxDataTwo2);
            this.groupBox2.Controls.Add(this.txtBoxDataOne2);
            this.groupBox2.Controls.Add(this.btnWriteBlock2);
            this.groupBox2.Controls.Add(this.btnReadSector2);
            this.groupBox2.Controls.Add(this.cbxSubmass2);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.cbxMass2);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(444, 65);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(426, 242);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Operator Frame";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(-247, 466);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(231, 24);
            this.textBox1.TabIndex = 31;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(-275, 470);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(33, 18);
            this.label9.TabIndex = 30;
            this.label9.Text = "Key";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(-360, 466);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(64, 22);
            this.radioButton1.TabIndex = 29;
            this.radioButton1.Text = "KeyB";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(-422, 466);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(63, 22);
            this.radioButton2.TabIndex = 28;
            this.radioButton2.Text = "KeyA";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(-144, 417);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(128, 24);
            this.textBox2.TabIndex = 27;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(-284, 417);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(137, 24);
            this.textBox3.TabIndex = 26;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(-422, 417);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(135, 24);
            this.textBox4.TabIndex = 25;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(-422, 388);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(407, 24);
            this.textBox5.TabIndex = 24;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(-422, 359);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(407, 24);
            this.textBox6.TabIndex = 23;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(-423, 330);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(407, 24);
            this.textBox7.TabIndex = 22;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(-103, 298);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 23);
            this.button1.TabIndex = 21;
            this.button1.Text = "Write Block";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(-199, 298);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(87, 23);
            this.button2.TabIndex = 20;
            this.button2.Text = "Read Sector";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(-270, 298);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(65, 26);
            this.comboBox1.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(-307, 301);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 18);
            this.label10.TabIndex = 18;
            this.label10.Text = "Block";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(-378, 298);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(65, 26);
            this.comboBox2.TabIndex = 17;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(-425, 301);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 18);
            this.label11.TabIndex = 16;
            this.label11.Text = "Sector";
            // 
            // txtInputKey2
            // 
            this.txtInputKey2.Location = new System.Drawing.Point(185, 203);
            this.txtInputKey2.Name = "txtInputKey2";
            this.txtInputKey2.Size = new System.Drawing.Size(231, 24);
            this.txtInputKey2.TabIndex = 15;
            this.txtInputKey2.Text = "FFFFFFFFFFFF";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(157, 207);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 18);
            this.label8.TabIndex = 14;
            this.label8.Text = "Key";
            // 
            // rbtKeyB2
            // 
            this.rbtKeyB2.AutoSize = true;
            this.rbtKeyB2.Location = new System.Drawing.Point(72, 203);
            this.rbtKeyB2.Name = "rbtKeyB2";
            this.rbtKeyB2.Size = new System.Drawing.Size(64, 22);
            this.rbtKeyB2.TabIndex = 13;
            this.rbtKeyB2.Text = "KeyB";
            this.rbtKeyB2.UseVisualStyleBackColor = true;
            // 
            // rbtKeyA2
            // 
            this.rbtKeyA2.AutoSize = true;
            this.rbtKeyA2.Checked = true;
            this.rbtKeyA2.Location = new System.Drawing.Point(10, 203);
            this.rbtKeyA2.Name = "rbtKeyA2";
            this.rbtKeyA2.Size = new System.Drawing.Size(63, 22);
            this.rbtKeyA2.TabIndex = 12;
            this.rbtKeyA2.TabStop = true;
            this.rbtKeyA2.Text = "KeyA";
            this.rbtKeyA2.UseVisualStyleBackColor = true;
            // 
            // txtKeyB2
            // 
            this.txtKeyB2.Location = new System.Drawing.Point(288, 154);
            this.txtKeyB2.Name = "txtKeyB2";
            this.txtKeyB2.Size = new System.Drawing.Size(128, 24);
            this.txtKeyB2.TabIndex = 11;
            // 
            // txtKey2
            // 
            this.txtKey2.Location = new System.Drawing.Point(148, 154);
            this.txtKey2.Name = "txtKey2";
            this.txtKey2.Size = new System.Drawing.Size(137, 24);
            this.txtKey2.TabIndex = 10;
            // 
            // txtKeyA2
            // 
            this.txtKeyA2.Location = new System.Drawing.Point(10, 154);
            this.txtKeyA2.Name = "txtKeyA2";
            this.txtKeyA2.Size = new System.Drawing.Size(135, 24);
            this.txtKeyA2.TabIndex = 9;
            // 
            // txtDataThree2
            // 
            this.txtDataThree2.Location = new System.Drawing.Point(10, 125);
            this.txtDataThree2.Name = "txtDataThree2";
            this.txtDataThree2.Size = new System.Drawing.Size(407, 24);
            this.txtDataThree2.TabIndex = 8;
            // 
            // txtBoxDataTwo2
            // 
            this.txtBoxDataTwo2.Location = new System.Drawing.Point(10, 96);
            this.txtBoxDataTwo2.Name = "txtBoxDataTwo2";
            this.txtBoxDataTwo2.Size = new System.Drawing.Size(407, 24);
            this.txtBoxDataTwo2.TabIndex = 7;
            // 
            // txtBoxDataOne2
            // 
            this.txtBoxDataOne2.Location = new System.Drawing.Point(9, 67);
            this.txtBoxDataOne2.Name = "txtBoxDataOne2";
            this.txtBoxDataOne2.Size = new System.Drawing.Size(407, 24);
            this.txtBoxDataOne2.TabIndex = 6;
            // 
            // btnWriteBlock2
            // 
            this.btnWriteBlock2.Location = new System.Drawing.Point(329, 35);
            this.btnWriteBlock2.Name = "btnWriteBlock2";
            this.btnWriteBlock2.Size = new System.Drawing.Size(87, 23);
            this.btnWriteBlock2.TabIndex = 5;
            this.btnWriteBlock2.Text = "Write Block";
            this.btnWriteBlock2.UseVisualStyleBackColor = true;
            this.btnWriteBlock2.Click += new System.EventHandler(this.btnWriteBlock2_Click);
            // 
            // btnReadSector2
            // 
            this.btnReadSector2.Location = new System.Drawing.Point(233, 35);
            this.btnReadSector2.Name = "btnReadSector2";
            this.btnReadSector2.Size = new System.Drawing.Size(87, 23);
            this.btnReadSector2.TabIndex = 4;
            this.btnReadSector2.Text = "Read Sector";
            this.btnReadSector2.UseVisualStyleBackColor = true;
            this.btnReadSector2.Click += new System.EventHandler(this.btnReadSector2_Click);
            // 
            // cbxSubmass2
            // 
            this.cbxSubmass2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSubmass2.FormattingEnabled = true;
            this.cbxSubmass2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.cbxSubmass2.Location = new System.Drawing.Point(162, 35);
            this.cbxSubmass2.MaxDropDownItems = 4;
            this.cbxSubmass2.Name = "cbxSubmass2";
            this.cbxSubmass2.Size = new System.Drawing.Size(65, 26);
            this.cbxSubmass2.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(125, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 18);
            this.label7.TabIndex = 2;
            this.label7.Text = "Block";
            // 
            // cbxMass2
            // 
            this.cbxMass2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxMass2.FormattingEnabled = true;
            this.cbxMass2.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbxMass2.Location = new System.Drawing.Point(54, 35);
            this.cbxMass2.MaxDropDownItems = 16;
            this.cbxMass2.Name = "cbxMass2";
            this.cbxMass2.Size = new System.Drawing.Size(65, 26);
            this.cbxMass2.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 18);
            this.label6.TabIndex = 0;
            this.label6.Text = "Sector";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox8);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.radioButton3);
            this.groupBox3.Controls.Add(this.radioButton4);
            this.groupBox3.Controls.Add(this.textBox9);
            this.groupBox3.Controls.Add(this.textBox10);
            this.groupBox3.Controls.Add(this.textBox11);
            this.groupBox3.Controls.Add(this.textBox12);
            this.groupBox3.Controls.Add(this.textBox13);
            this.groupBox3.Controls.Add(this.textBox14);
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.comboBox3);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.comboBox4);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.txtInputKey3);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.rbtKeyB3);
            this.groupBox3.Controls.Add(this.rbtKeyA3);
            this.groupBox3.Controls.Add(this.txtKeyB3);
            this.groupBox3.Controls.Add(this.txtKey3);
            this.groupBox3.Controls.Add(this.txtKeyA3);
            this.groupBox3.Controls.Add(this.txtDataThree3);
            this.groupBox3.Controls.Add(this.txtDataTwo3);
            this.groupBox3.Controls.Add(this.txtDataOne3);
            this.groupBox3.Controls.Add(this.btnWriteBlock3);
            this.groupBox3.Controls.Add(this.btnReadSector3);
            this.groupBox3.Controls.Add(this.cbxSubmass3);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.cbxMass3);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Location = new System.Drawing.Point(12, 309);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(426, 242);
            this.groupBox3.TabIndex = 32;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Operator Frame";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(-247, 466);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(231, 24);
            this.textBox8.TabIndex = 31;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(-275, 470);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(33, 18);
            this.label12.TabIndex = 30;
            this.label12.Text = "Key";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(-360, 466);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(64, 22);
            this.radioButton3.TabIndex = 29;
            this.radioButton3.Text = "KeyB";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(-422, 466);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(63, 22);
            this.radioButton4.TabIndex = 28;
            this.radioButton4.Text = "KeyA";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(-144, 417);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(128, 24);
            this.textBox9.TabIndex = 27;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(-284, 417);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(137, 24);
            this.textBox10.TabIndex = 26;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(-422, 417);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(135, 24);
            this.textBox11.TabIndex = 25;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(-422, 388);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(407, 24);
            this.textBox12.TabIndex = 24;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(-422, 359);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(407, 24);
            this.textBox13.TabIndex = 23;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(-423, 330);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(407, 24);
            this.textBox14.TabIndex = 22;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(-103, 298);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(87, 23);
            this.button3.TabIndex = 21;
            this.button3.Text = "Write Block";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(-199, 298);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 23);
            this.button4.TabIndex = 20;
            this.button4.Text = "Read Sector";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(-270, 298);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(65, 26);
            this.comboBox3.TabIndex = 19;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(-307, 301);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 18);
            this.label13.TabIndex = 18;
            this.label13.Text = "Block";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(-378, 298);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(65, 26);
            this.comboBox4.TabIndex = 17;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(-425, 301);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 18);
            this.label14.TabIndex = 16;
            this.label14.Text = "Sector";
            // 
            // txtInputKey3
            // 
            this.txtInputKey3.Location = new System.Drawing.Point(185, 203);
            this.txtInputKey3.Name = "txtInputKey3";
            this.txtInputKey3.Size = new System.Drawing.Size(231, 24);
            this.txtInputKey3.TabIndex = 15;
            this.txtInputKey3.Text = "FFFFFFFFFFFF";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(157, 207);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(33, 18);
            this.label15.TabIndex = 14;
            this.label15.Text = "Key";
            // 
            // rbtKeyB3
            // 
            this.rbtKeyB3.AutoSize = true;
            this.rbtKeyB3.Location = new System.Drawing.Point(72, 203);
            this.rbtKeyB3.Name = "rbtKeyB3";
            this.rbtKeyB3.Size = new System.Drawing.Size(64, 22);
            this.rbtKeyB3.TabIndex = 13;
            this.rbtKeyB3.Text = "KeyB";
            this.rbtKeyB3.UseVisualStyleBackColor = true;
            // 
            // rbtKeyA3
            // 
            this.rbtKeyA3.AutoSize = true;
            this.rbtKeyA3.Checked = true;
            this.rbtKeyA3.Location = new System.Drawing.Point(10, 203);
            this.rbtKeyA3.Name = "rbtKeyA3";
            this.rbtKeyA3.Size = new System.Drawing.Size(63, 22);
            this.rbtKeyA3.TabIndex = 12;
            this.rbtKeyA3.TabStop = true;
            this.rbtKeyA3.Text = "KeyA";
            this.rbtKeyA3.UseVisualStyleBackColor = true;
            // 
            // txtKeyB3
            // 
            this.txtKeyB3.Location = new System.Drawing.Point(288, 154);
            this.txtKeyB3.Name = "txtKeyB3";
            this.txtKeyB3.Size = new System.Drawing.Size(128, 24);
            this.txtKeyB3.TabIndex = 11;
            // 
            // txtKey3
            // 
            this.txtKey3.Location = new System.Drawing.Point(148, 154);
            this.txtKey3.Name = "txtKey3";
            this.txtKey3.Size = new System.Drawing.Size(137, 24);
            this.txtKey3.TabIndex = 10;
            // 
            // txtKeyA3
            // 
            this.txtKeyA3.Location = new System.Drawing.Point(10, 154);
            this.txtKeyA3.Name = "txtKeyA3";
            this.txtKeyA3.Size = new System.Drawing.Size(135, 24);
            this.txtKeyA3.TabIndex = 9;
            // 
            // txtDataThree3
            // 
            this.txtDataThree3.Location = new System.Drawing.Point(10, 125);
            this.txtDataThree3.Name = "txtDataThree3";
            this.txtDataThree3.Size = new System.Drawing.Size(407, 24);
            this.txtDataThree3.TabIndex = 8;
            // 
            // txtDataTwo3
            // 
            this.txtDataTwo3.Location = new System.Drawing.Point(10, 96);
            this.txtDataTwo3.Name = "txtDataTwo3";
            this.txtDataTwo3.Size = new System.Drawing.Size(407, 24);
            this.txtDataTwo3.TabIndex = 7;
            // 
            // txtDataOne3
            // 
            this.txtDataOne3.Location = new System.Drawing.Point(9, 67);
            this.txtDataOne3.Name = "txtDataOne3";
            this.txtDataOne3.Size = new System.Drawing.Size(407, 24);
            this.txtDataOne3.TabIndex = 6;
            // 
            // btnWriteBlock3
            // 
            this.btnWriteBlock3.Location = new System.Drawing.Point(329, 35);
            this.btnWriteBlock3.Name = "btnWriteBlock3";
            this.btnWriteBlock3.Size = new System.Drawing.Size(87, 23);
            this.btnWriteBlock3.TabIndex = 5;
            this.btnWriteBlock3.Text = "Write Block";
            this.btnWriteBlock3.UseVisualStyleBackColor = true;
            this.btnWriteBlock3.Click += new System.EventHandler(this.btnWriteBlock3_Click);
            // 
            // btnReadSector3
            // 
            this.btnReadSector3.Location = new System.Drawing.Point(233, 35);
            this.btnReadSector3.Name = "btnReadSector3";
            this.btnReadSector3.Size = new System.Drawing.Size(87, 23);
            this.btnReadSector3.TabIndex = 4;
            this.btnReadSector3.Text = "Read Sector";
            this.btnReadSector3.UseVisualStyleBackColor = true;
            this.btnReadSector3.Click += new System.EventHandler(this.btnReadSector3_Click);
            // 
            // cbxSubmass3
            // 
            this.cbxSubmass3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSubmass3.FormattingEnabled = true;
            this.cbxSubmass3.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.cbxSubmass3.Location = new System.Drawing.Point(162, 35);
            this.cbxSubmass3.MaxDropDownItems = 4;
            this.cbxSubmass3.Name = "cbxSubmass3";
            this.cbxSubmass3.Size = new System.Drawing.Size(65, 26);
            this.cbxSubmass3.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(125, 38);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(46, 18);
            this.label16.TabIndex = 2;
            this.label16.Text = "Block";
            // 
            // cbxMass3
            // 
            this.cbxMass3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxMass3.FormattingEnabled = true;
            this.cbxMass3.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbxMass3.Location = new System.Drawing.Point(54, 35);
            this.cbxMass3.MaxDropDownItems = 16;
            this.cbxMass3.Name = "cbxMass3";
            this.cbxMass3.Size = new System.Drawing.Size(65, 26);
            this.cbxMass3.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(7, 38);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(52, 18);
            this.label17.TabIndex = 0;
            this.label17.Text = "Sector";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox22);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.radioButton7);
            this.groupBox4.Controls.Add(this.radioButton8);
            this.groupBox4.Controls.Add(this.textBox23);
            this.groupBox4.Controls.Add(this.textBox24);
            this.groupBox4.Controls.Add(this.textBox25);
            this.groupBox4.Controls.Add(this.textBox26);
            this.groupBox4.Controls.Add(this.textBox27);
            this.groupBox4.Controls.Add(this.textBox28);
            this.groupBox4.Controls.Add(this.button7);
            this.groupBox4.Controls.Add(this.button8);
            this.groupBox4.Controls.Add(this.comboBox7);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.comboBox8);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.txtInputKey4);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.rbtKeyB4);
            this.groupBox4.Controls.Add(this.rbtKeyA4);
            this.groupBox4.Controls.Add(this.txtKeyB4);
            this.groupBox4.Controls.Add(this.txtKey4);
            this.groupBox4.Controls.Add(this.txtKeyA4);
            this.groupBox4.Controls.Add(this.txtDataThree4);
            this.groupBox4.Controls.Add(this.txtDataTwo4);
            this.groupBox4.Controls.Add(this.txtDataOne4);
            this.groupBox4.Controls.Add(this.btnWriteBlock4);
            this.groupBox4.Controls.Add(this.btnReadSector4);
            this.groupBox4.Controls.Add(this.cbxSubmass4);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.cbxMass4);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Location = new System.Drawing.Point(444, 309);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(426, 242);
            this.groupBox4.TabIndex = 32;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Operator Frame";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(-247, 466);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(231, 24);
            this.textBox22.TabIndex = 31;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(-275, 470);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(33, 18);
            this.label18.TabIndex = 30;
            this.label18.Text = "Key";
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(-360, 466);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(64, 22);
            this.radioButton7.TabIndex = 29;
            this.radioButton7.Text = "KeyB";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(-422, 466);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(63, 22);
            this.radioButton8.TabIndex = 28;
            this.radioButton8.Text = "KeyA";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(-144, 417);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(128, 24);
            this.textBox23.TabIndex = 27;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(-284, 417);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(137, 24);
            this.textBox24.TabIndex = 26;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(-422, 417);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(135, 24);
            this.textBox25.TabIndex = 25;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(-422, 388);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(407, 24);
            this.textBox26.TabIndex = 24;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(-422, 359);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(407, 24);
            this.textBox27.TabIndex = 23;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(-423, 330);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(407, 24);
            this.textBox28.TabIndex = 22;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(-103, 298);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(87, 23);
            this.button7.TabIndex = 21;
            this.button7.Text = "Write Block";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(-199, 298);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(87, 23);
            this.button8.TabIndex = 20;
            this.button8.Text = "Read Sector";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(-270, 298);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(65, 26);
            this.comboBox7.TabIndex = 19;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(-307, 301);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(46, 18);
            this.label19.TabIndex = 18;
            this.label19.Text = "Block";
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Location = new System.Drawing.Point(-378, 298);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(65, 26);
            this.comboBox8.TabIndex = 17;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(-425, 301);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(52, 18);
            this.label20.TabIndex = 16;
            this.label20.Text = "Sector";
            // 
            // txtInputKey4
            // 
            this.txtInputKey4.Location = new System.Drawing.Point(185, 203);
            this.txtInputKey4.Name = "txtInputKey4";
            this.txtInputKey4.Size = new System.Drawing.Size(231, 24);
            this.txtInputKey4.TabIndex = 15;
            this.txtInputKey4.Text = "FFFFFFFFFFFF";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(157, 207);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(33, 18);
            this.label21.TabIndex = 14;
            this.label21.Text = "Key";
            // 
            // rbtKeyB4
            // 
            this.rbtKeyB4.AutoSize = true;
            this.rbtKeyB4.Location = new System.Drawing.Point(72, 203);
            this.rbtKeyB4.Name = "rbtKeyB4";
            this.rbtKeyB4.Size = new System.Drawing.Size(64, 22);
            this.rbtKeyB4.TabIndex = 13;
            this.rbtKeyB4.Text = "KeyB";
            this.rbtKeyB4.UseVisualStyleBackColor = true;
            // 
            // rbtKeyA4
            // 
            this.rbtKeyA4.AutoSize = true;
            this.rbtKeyA4.Checked = true;
            this.rbtKeyA4.Location = new System.Drawing.Point(10, 203);
            this.rbtKeyA4.Name = "rbtKeyA4";
            this.rbtKeyA4.Size = new System.Drawing.Size(63, 22);
            this.rbtKeyA4.TabIndex = 12;
            this.rbtKeyA4.TabStop = true;
            this.rbtKeyA4.Text = "KeyA";
            this.rbtKeyA4.UseVisualStyleBackColor = true;
            // 
            // txtKeyB4
            // 
            this.txtKeyB4.Location = new System.Drawing.Point(288, 154);
            this.txtKeyB4.Name = "txtKeyB4";
            this.txtKeyB4.Size = new System.Drawing.Size(128, 24);
            this.txtKeyB4.TabIndex = 11;
            // 
            // txtKey4
            // 
            this.txtKey4.Location = new System.Drawing.Point(148, 154);
            this.txtKey4.Name = "txtKey4";
            this.txtKey4.Size = new System.Drawing.Size(137, 24);
            this.txtKey4.TabIndex = 10;
            // 
            // txtKeyA4
            // 
            this.txtKeyA4.Location = new System.Drawing.Point(10, 154);
            this.txtKeyA4.Name = "txtKeyA4";
            this.txtKeyA4.Size = new System.Drawing.Size(135, 24);
            this.txtKeyA4.TabIndex = 9;
            // 
            // txtDataThree4
            // 
            this.txtDataThree4.Location = new System.Drawing.Point(10, 125);
            this.txtDataThree4.Name = "txtDataThree4";
            this.txtDataThree4.Size = new System.Drawing.Size(407, 24);
            this.txtDataThree4.TabIndex = 8;
            // 
            // txtDataTwo4
            // 
            this.txtDataTwo4.Location = new System.Drawing.Point(10, 96);
            this.txtDataTwo4.Name = "txtDataTwo4";
            this.txtDataTwo4.Size = new System.Drawing.Size(407, 24);
            this.txtDataTwo4.TabIndex = 7;
            // 
            // txtDataOne4
            // 
            this.txtDataOne4.Location = new System.Drawing.Point(9, 67);
            this.txtDataOne4.Name = "txtDataOne4";
            this.txtDataOne4.Size = new System.Drawing.Size(407, 24);
            this.txtDataOne4.TabIndex = 6;
            // 
            // btnWriteBlock4
            // 
            this.btnWriteBlock4.Location = new System.Drawing.Point(329, 35);
            this.btnWriteBlock4.Name = "btnWriteBlock4";
            this.btnWriteBlock4.Size = new System.Drawing.Size(87, 23);
            this.btnWriteBlock4.TabIndex = 5;
            this.btnWriteBlock4.Text = "Write Block";
            this.btnWriteBlock4.UseVisualStyleBackColor = true;
            this.btnWriteBlock4.Click += new System.EventHandler(this.btnWriteBlock4_Click);
            // 
            // btnReadSector4
            // 
            this.btnReadSector4.Location = new System.Drawing.Point(233, 35);
            this.btnReadSector4.Name = "btnReadSector4";
            this.btnReadSector4.Size = new System.Drawing.Size(87, 23);
            this.btnReadSector4.TabIndex = 4;
            this.btnReadSector4.Text = "Read Sector";
            this.btnReadSector4.UseVisualStyleBackColor = true;
            this.btnReadSector4.Click += new System.EventHandler(this.btnReadSector4_Click);
            // 
            // cbxSubmass4
            // 
            this.cbxSubmass4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSubmass4.FormattingEnabled = true;
            this.cbxSubmass4.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.cbxSubmass4.Location = new System.Drawing.Point(162, 35);
            this.cbxSubmass4.MaxDropDownItems = 4;
            this.cbxSubmass4.Name = "cbxSubmass4";
            this.cbxSubmass4.Size = new System.Drawing.Size(65, 26);
            this.cbxSubmass4.TabIndex = 3;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(125, 38);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(46, 18);
            this.label22.TabIndex = 2;
            this.label22.Text = "Block";
            // 
            // cbxMass4
            // 
            this.cbxMass4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxMass4.FormattingEnabled = true;
            this.cbxMass4.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbxMass4.Location = new System.Drawing.Point(54, 35);
            this.cbxMass4.MaxDropDownItems = 16;
            this.cbxMass4.Name = "cbxMass4";
            this.cbxMass4.Size = new System.Drawing.Size(65, 26);
            this.cbxMass4.TabIndex = 1;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(7, 38);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(52, 18);
            this.label23.TabIndex = 0;
            this.label23.Text = "Sector";
            // 
            // tsMifare1K
            // 
            this.tsMifare1K.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnConnect,
            this.toolStripSeparator1});
            this.tsMifare1K.Location = new System.Drawing.Point(0, 0);
            this.tsMifare1K.Name = "tsMifare1K";
            this.tsMifare1K.Size = new System.Drawing.Size(881, 27);
            this.tsMifare1K.TabIndex = 33;
            this.tsMifare1K.Text = "Mifare1K";
            // 
            // tsbtnConnect
            // 
            this.tsbtnConnect.BackColor = System.Drawing.SystemColors.Control;
            this.tsbtnConnect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbtnConnect.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnConnect.Image")));
            this.tsbtnConnect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnConnect.Name = "tsbtnConnect";
            this.tsbtnConnect.Size = new System.Drawing.Size(74, 24);
            this.tsbtnConnect.Text = "Connect";
            this.tsbtnConnect.Click += new System.EventHandler(this.tsbtnConnect_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // Mifare_1K
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(881, 562);
            this.Controls.Add(this.tsMifare1K);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnHalt);
            this.Controls.Add(this.btnReqIDL);
            this.Controls.Add(this.btnRequest);
            this.Controls.Add(this.txtSearchPurse);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Mifare_1K";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mifare_1K";
            this.Load += new System.EventHandler(this.Mifare_1K_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tsMifare1K.ResumeLayout(false);
            this.tsMifare1K.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSearchPurse;
        private System.Windows.Forms.Button btnRequest;
        private System.Windows.Forms.Button btnReqIDL;
        private System.Windows.Forms.Button btnHalt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbtPurseKeyB;
        private System.Windows.Forms.RadioButton rbtPurseKeyA;
        private System.Windows.Forms.ComboBox cbxSubmass1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbxMass1;
        private System.Windows.Forms.TextBox txtBoxPurseHex;
        private System.Windows.Forms.TextBox txtPurseDec;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxPurseKey;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCreditCardBalance;
        private System.Windows.Forms.Button btnCreditCardDecrement;
        private System.Windows.Forms.Button btnCreditCardIncrement;
        private System.Windows.Forms.Button btnPurseInit;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbxMass2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnWriteBlock2;
        private System.Windows.Forms.Button btnReadSector2;
        private System.Windows.Forms.ComboBox cbxSubmass2;
        private System.Windows.Forms.TextBox txtKeyB2;
        private System.Windows.Forms.TextBox txtKey2;
        private System.Windows.Forms.TextBox txtKeyA2;
        private System.Windows.Forms.TextBox txtDataThree2;
        private System.Windows.Forms.TextBox txtBoxDataTwo2;
        private System.Windows.Forms.TextBox txtBoxDataOne2;
        private System.Windows.Forms.TextBox txtInputKey2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton rbtKeyB2;
        private System.Windows.Forms.RadioButton rbtKeyA2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtInputKey3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RadioButton rbtKeyB3;
        private System.Windows.Forms.RadioButton rbtKeyA3;
        private System.Windows.Forms.TextBox txtKeyB3;
        private System.Windows.Forms.TextBox txtKey3;
        private System.Windows.Forms.TextBox txtKeyA3;
        private System.Windows.Forms.TextBox txtDataThree3;
        private System.Windows.Forms.TextBox txtDataTwo3;
        private System.Windows.Forms.TextBox txtDataOne3;
        private System.Windows.Forms.Button btnWriteBlock3;
        private System.Windows.Forms.Button btnReadSector3;
        private System.Windows.Forms.ComboBox cbxSubmass3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cbxMass3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtInputKey4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.RadioButton rbtKeyB4;
        private System.Windows.Forms.RadioButton rbtKeyA4;
        private System.Windows.Forms.TextBox txtKeyB4;
        private System.Windows.Forms.TextBox txtKey4;
        private System.Windows.Forms.TextBox txtKeyA4;
        private System.Windows.Forms.TextBox txtDataThree4;
        private System.Windows.Forms.TextBox txtDataTwo4;
        private System.Windows.Forms.TextBox txtDataOne4;
        private System.Windows.Forms.Button btnWriteBlock4;
        private System.Windows.Forms.Button btnReadSector4;
        private System.Windows.Forms.ComboBox cbxSubmass4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cbxMass4;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ToolStrip tsMifare1K;
        private System.Windows.Forms.ToolStripButton tsbtnConnect;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    }
}

