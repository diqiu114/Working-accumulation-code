﻿namespace Mifare1K
{
    partial class FM1208
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FM1208));
            this.tsbtnConnect = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsRefreshDevice = new System.Windows.Forms.ToolStrip();
            this.textDeviceSN1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btnConn1 = new System.Windows.Forms.Button();
            this.btnBeep1 = new System.Windows.Forms.Button();
            this.textConnStatus1 = new System.Windows.Forms.TextBox();
            this.textConnStatus2 = new System.Windows.Forms.TextBox();
            this.btnBeep2 = new System.Windows.Forms.Button();
            this.btnConn2 = new System.Windows.Forms.Button();
            this.textDeviceSN2 = new System.Windows.Forms.TextBox();
            this.textConnStatus3 = new System.Windows.Forms.TextBox();
            this.btnBeep3 = new System.Windows.Forms.Button();
            this.btnConn3 = new System.Windows.Forms.Button();
            this.textDeviceSN3 = new System.Windows.Forms.TextBox();
            this.textConnStatus4 = new System.Windows.Forms.TextBox();
            this.btnBeep4 = new System.Windows.Forms.Button();
            this.btnConn4 = new System.Windows.Forms.Button();
            this.textDeviceSN4 = new System.Windows.Forms.TextBox();
            this.textConnStatus5 = new System.Windows.Forms.TextBox();
            this.btnBeep5 = new System.Windows.Forms.Button();
            this.btnConn5 = new System.Windows.Forms.Button();
            this.textDeviceSN5 = new System.Windows.Forms.TextBox();
            this.textConnStatus6 = new System.Windows.Forms.TextBox();
            this.btnBeep6 = new System.Windows.Forms.Button();
            this.btnConn6 = new System.Windows.Forms.Button();
            this.textDeviceSN6 = new System.Windows.Forms.TextBox();
            this.textConnStatus7 = new System.Windows.Forms.TextBox();
            this.btnBeep7 = new System.Windows.Forms.Button();
            this.btnConn7 = new System.Windows.Forms.Button();
            this.textDeviceSN7 = new System.Windows.Forms.TextBox();
            this.textConnStatus8 = new System.Windows.Forms.TextBox();
            this.btnBeep8 = new System.Windows.Forms.Button();
            this.btnConn8 = new System.Windows.Forms.Button();
            this.textDeviceSN8 = new System.Windows.Forms.TextBox();
            this.tsRefreshDevice.SuspendLayout();
            this.SuspendLayout();
            // 
            // tsbtnConnect
            // 
            this.tsbtnConnect.BackColor = System.Drawing.SystemColors.Control;
            this.tsbtnConnect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbtnConnect.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnConnect.Image")));
            this.tsbtnConnect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnConnect.Name = "tsbtnConnect";
            this.tsbtnConnect.Size = new System.Drawing.Size(98, 22);
            this.tsbtnConnect.Text = "Refresh Device";
            this.tsbtnConnect.Click += new System.EventHandler(this.tsbtnConnect_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsRefreshDevice
            // 
            this.tsRefreshDevice.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnConnect,
            this.toolStripSeparator1});
            this.tsRefreshDevice.Location = new System.Drawing.Point(0, 0);
            this.tsRefreshDevice.Name = "tsRefreshDevice";
            this.tsRefreshDevice.Size = new System.Drawing.Size(568, 25);
            this.tsRefreshDevice.TabIndex = 33;
            this.tsRefreshDevice.Text = "Mifare1K";
            // 
            // textDeviceSN1
            // 
            this.textDeviceSN1.Location = new System.Drawing.Point(102, 39);
            this.textDeviceSN1.Name = "textDeviceSN1";
            this.textDeviceSN1.Size = new System.Drawing.Size(91, 21);
            this.textDeviceSN1.TabIndex = 34;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 15);
            this.label1.TabIndex = 35;
            this.label1.Text = "Device1:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 15);
            this.label2.TabIndex = 36;
            this.label2.Text = "Device2:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 15);
            this.label3.TabIndex = 37;
            this.label3.Text = "Device3:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 198);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 15);
            this.label4.TabIndex = 38;
            this.label4.Text = "Device5:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 237);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 15);
            this.label5.TabIndex = 39;
            this.label5.Text = "Device6:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 276);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 15);
            this.label6.TabIndex = 40;
            this.label6.Text = "Device7:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 315);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 15);
            this.label7.TabIndex = 41;
            this.label7.Text = "Device8:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(42, 159);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 15);
            this.label10.TabIndex = 44;
            this.label10.Text = "Device4:";
            // 
            // btnConn1
            // 
            this.btnConn1.Location = new System.Drawing.Point(324, 38);
            this.btnConn1.Name = "btnConn1";
            this.btnConn1.Size = new System.Drawing.Size(83, 23);
            this.btnConn1.TabIndex = 45;
            this.btnConn1.Text = "Connect";
            this.btnConn1.UseVisualStyleBackColor = true;
            this.btnConn1.Click += new System.EventHandler(this.btnConn1_Click);
            // 
            // btnBeep1
            // 
            this.btnBeep1.Location = new System.Drawing.Point(421, 38);
            this.btnBeep1.Name = "btnBeep1";
            this.btnBeep1.Size = new System.Drawing.Size(83, 23);
            this.btnBeep1.TabIndex = 46;
            this.btnBeep1.Text = "Beep";
            this.btnBeep1.UseVisualStyleBackColor = true;
            this.btnBeep1.Click += new System.EventHandler(this.btnBeep1_Click);
            // 
            // textConnStatus1
            // 
            this.textConnStatus1.Location = new System.Drawing.Point(212, 39);
            this.textConnStatus1.Name = "textConnStatus1";
            this.textConnStatus1.Size = new System.Drawing.Size(97, 21);
            this.textConnStatus1.TabIndex = 47;
            // 
            // textConnStatus2
            // 
            this.textConnStatus2.Location = new System.Drawing.Point(212, 81);
            this.textConnStatus2.Name = "textConnStatus2";
            this.textConnStatus2.Size = new System.Drawing.Size(97, 21);
            this.textConnStatus2.TabIndex = 51;
            // 
            // btnBeep2
            // 
            this.btnBeep2.Location = new System.Drawing.Point(421, 80);
            this.btnBeep2.Name = "btnBeep2";
            this.btnBeep2.Size = new System.Drawing.Size(83, 23);
            this.btnBeep2.TabIndex = 50;
            this.btnBeep2.Text = "Beep";
            this.btnBeep2.UseVisualStyleBackColor = true;
            this.btnBeep2.Click += new System.EventHandler(this.btnBeep2_Click);
            // 
            // btnConn2
            // 
            this.btnConn2.Location = new System.Drawing.Point(324, 80);
            this.btnConn2.Name = "btnConn2";
            this.btnConn2.Size = new System.Drawing.Size(83, 23);
            this.btnConn2.TabIndex = 49;
            this.btnConn2.Text = "Connect";
            this.btnConn2.UseVisualStyleBackColor = true;
            this.btnConn2.Click += new System.EventHandler(this.btnConn2_Click);
            // 
            // textDeviceSN2
            // 
            this.textDeviceSN2.Location = new System.Drawing.Point(102, 81);
            this.textDeviceSN2.Name = "textDeviceSN2";
            this.textDeviceSN2.Size = new System.Drawing.Size(91, 21);
            this.textDeviceSN2.TabIndex = 48;
            // 
            // textConnStatus3
            // 
            this.textConnStatus3.Location = new System.Drawing.Point(212, 120);
            this.textConnStatus3.Name = "textConnStatus3";
            this.textConnStatus3.Size = new System.Drawing.Size(97, 21);
            this.textConnStatus3.TabIndex = 55;
            // 
            // btnBeep3
            // 
            this.btnBeep3.Location = new System.Drawing.Point(421, 119);
            this.btnBeep3.Name = "btnBeep3";
            this.btnBeep3.Size = new System.Drawing.Size(83, 23);
            this.btnBeep3.TabIndex = 54;
            this.btnBeep3.Text = "Beep";
            this.btnBeep3.UseVisualStyleBackColor = true;
            this.btnBeep3.Click += new System.EventHandler(this.btnBeep3_Click);
            // 
            // btnConn3
            // 
            this.btnConn3.Location = new System.Drawing.Point(324, 119);
            this.btnConn3.Name = "btnConn3";
            this.btnConn3.Size = new System.Drawing.Size(83, 23);
            this.btnConn3.TabIndex = 53;
            this.btnConn3.Text = "Connect";
            this.btnConn3.UseVisualStyleBackColor = true;
            this.btnConn3.Click += new System.EventHandler(this.btnConn3_Click);
            // 
            // textDeviceSN3
            // 
            this.textDeviceSN3.Location = new System.Drawing.Point(102, 120);
            this.textDeviceSN3.Name = "textDeviceSN3";
            this.textDeviceSN3.Size = new System.Drawing.Size(91, 21);
            this.textDeviceSN3.TabIndex = 52;
            // 
            // textConnStatus4
            // 
            this.textConnStatus4.Location = new System.Drawing.Point(212, 159);
            this.textConnStatus4.Name = "textConnStatus4";
            this.textConnStatus4.Size = new System.Drawing.Size(97, 21);
            this.textConnStatus4.TabIndex = 59;
            // 
            // btnBeep4
            // 
            this.btnBeep4.Location = new System.Drawing.Point(421, 158);
            this.btnBeep4.Name = "btnBeep4";
            this.btnBeep4.Size = new System.Drawing.Size(83, 23);
            this.btnBeep4.TabIndex = 58;
            this.btnBeep4.Text = "Beep";
            this.btnBeep4.UseVisualStyleBackColor = true;
            this.btnBeep4.Click += new System.EventHandler(this.btnBeep4_Click);
            // 
            // btnConn4
            // 
            this.btnConn4.Location = new System.Drawing.Point(324, 158);
            this.btnConn4.Name = "btnConn4";
            this.btnConn4.Size = new System.Drawing.Size(83, 23);
            this.btnConn4.TabIndex = 57;
            this.btnConn4.Text = "Connect";
            this.btnConn4.UseVisualStyleBackColor = true;
            this.btnConn4.Click += new System.EventHandler(this.btnConn4_Click);
            // 
            // textDeviceSN4
            // 
            this.textDeviceSN4.Location = new System.Drawing.Point(102, 159);
            this.textDeviceSN4.Name = "textDeviceSN4";
            this.textDeviceSN4.Size = new System.Drawing.Size(91, 21);
            this.textDeviceSN4.TabIndex = 56;
            // 
            // textConnStatus5
            // 
            this.textConnStatus5.Location = new System.Drawing.Point(212, 198);
            this.textConnStatus5.Name = "textConnStatus5";
            this.textConnStatus5.Size = new System.Drawing.Size(97, 21);
            this.textConnStatus5.TabIndex = 63;
            // 
            // btnBeep5
            // 
            this.btnBeep5.Location = new System.Drawing.Point(421, 197);
            this.btnBeep5.Name = "btnBeep5";
            this.btnBeep5.Size = new System.Drawing.Size(83, 23);
            this.btnBeep5.TabIndex = 62;
            this.btnBeep5.Text = "Beep";
            this.btnBeep5.UseVisualStyleBackColor = true;
            this.btnBeep5.Click += new System.EventHandler(this.btnBeep5_Click);
            // 
            // btnConn5
            // 
            this.btnConn5.Location = new System.Drawing.Point(324, 197);
            this.btnConn5.Name = "btnConn5";
            this.btnConn5.Size = new System.Drawing.Size(83, 23);
            this.btnConn5.TabIndex = 61;
            this.btnConn5.Text = "Connect";
            this.btnConn5.UseVisualStyleBackColor = true;
            this.btnConn5.Click += new System.EventHandler(this.btnConn5_Click);
            // 
            // textDeviceSN5
            // 
            this.textDeviceSN5.Location = new System.Drawing.Point(102, 198);
            this.textDeviceSN5.Name = "textDeviceSN5";
            this.textDeviceSN5.Size = new System.Drawing.Size(91, 21);
            this.textDeviceSN5.TabIndex = 60;
            // 
            // textConnStatus6
            // 
            this.textConnStatus6.Location = new System.Drawing.Point(212, 237);
            this.textConnStatus6.Name = "textConnStatus6";
            this.textConnStatus6.Size = new System.Drawing.Size(97, 21);
            this.textConnStatus6.TabIndex = 67;
            // 
            // btnBeep6
            // 
            this.btnBeep6.Location = new System.Drawing.Point(421, 236);
            this.btnBeep6.Name = "btnBeep6";
            this.btnBeep6.Size = new System.Drawing.Size(83, 23);
            this.btnBeep6.TabIndex = 66;
            this.btnBeep6.Text = "Beep";
            this.btnBeep6.UseVisualStyleBackColor = true;
            this.btnBeep6.Click += new System.EventHandler(this.btnBeep6_Click);
            // 
            // btnConn6
            // 
            this.btnConn6.Location = new System.Drawing.Point(324, 236);
            this.btnConn6.Name = "btnConn6";
            this.btnConn6.Size = new System.Drawing.Size(83, 23);
            this.btnConn6.TabIndex = 65;
            this.btnConn6.Text = "Connect";
            this.btnConn6.UseVisualStyleBackColor = true;
            this.btnConn6.Click += new System.EventHandler(this.btnConn6_Click);
            // 
            // textDeviceSN6
            // 
            this.textDeviceSN6.Location = new System.Drawing.Point(102, 237);
            this.textDeviceSN6.Name = "textDeviceSN6";
            this.textDeviceSN6.Size = new System.Drawing.Size(91, 21);
            this.textDeviceSN6.TabIndex = 64;
            // 
            // textConnStatus7
            // 
            this.textConnStatus7.Location = new System.Drawing.Point(212, 276);
            this.textConnStatus7.Name = "textConnStatus7";
            this.textConnStatus7.Size = new System.Drawing.Size(97, 21);
            this.textConnStatus7.TabIndex = 71;
            // 
            // btnBeep7
            // 
            this.btnBeep7.Location = new System.Drawing.Point(421, 275);
            this.btnBeep7.Name = "btnBeep7";
            this.btnBeep7.Size = new System.Drawing.Size(83, 23);
            this.btnBeep7.TabIndex = 70;
            this.btnBeep7.Text = "Beep";
            this.btnBeep7.UseVisualStyleBackColor = true;
            this.btnBeep7.Click += new System.EventHandler(this.btnBeep7_Click);
            // 
            // btnConn7
            // 
            this.btnConn7.Location = new System.Drawing.Point(324, 275);
            this.btnConn7.Name = "btnConn7";
            this.btnConn7.Size = new System.Drawing.Size(83, 23);
            this.btnConn7.TabIndex = 69;
            this.btnConn7.Text = "Connect";
            this.btnConn7.UseVisualStyleBackColor = true;
            this.btnConn7.Click += new System.EventHandler(this.btnConn7_Click);
            // 
            // textDeviceSN7
            // 
            this.textDeviceSN7.Location = new System.Drawing.Point(102, 276);
            this.textDeviceSN7.Name = "textDeviceSN7";
            this.textDeviceSN7.Size = new System.Drawing.Size(91, 21);
            this.textDeviceSN7.TabIndex = 68;
            // 
            // textConnStatus8
            // 
            this.textConnStatus8.Location = new System.Drawing.Point(212, 315);
            this.textConnStatus8.Name = "textConnStatus8";
            this.textConnStatus8.Size = new System.Drawing.Size(97, 21);
            this.textConnStatus8.TabIndex = 75;
            // 
            // btnBeep8
            // 
            this.btnBeep8.Location = new System.Drawing.Point(421, 314);
            this.btnBeep8.Name = "btnBeep8";
            this.btnBeep8.Size = new System.Drawing.Size(83, 23);
            this.btnBeep8.TabIndex = 74;
            this.btnBeep8.Text = "Beep";
            this.btnBeep8.UseVisualStyleBackColor = true;
            this.btnBeep8.Click += new System.EventHandler(this.btnBeep8_Click);
            // 
            // btnConn8
            // 
            this.btnConn8.Location = new System.Drawing.Point(324, 314);
            this.btnConn8.Name = "btnConn8";
            this.btnConn8.Size = new System.Drawing.Size(83, 23);
            this.btnConn8.TabIndex = 73;
            this.btnConn8.Text = "Connect";
            this.btnConn8.UseVisualStyleBackColor = true;
            this.btnConn8.Click += new System.EventHandler(this.btnConn8_Click);
            // 
            // textDeviceSN8
            // 
            this.textDeviceSN8.Location = new System.Drawing.Point(102, 315);
            this.textDeviceSN8.Name = "textDeviceSN8";
            this.textDeviceSN8.Size = new System.Drawing.Size(91, 21);
            this.textDeviceSN8.TabIndex = 72;
            // 
            // FM1208
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(568, 365);
            this.Controls.Add(this.textConnStatus8);
            this.Controls.Add(this.btnBeep8);
            this.Controls.Add(this.btnConn8);
            this.Controls.Add(this.textDeviceSN8);
            this.Controls.Add(this.textConnStatus7);
            this.Controls.Add(this.btnBeep7);
            this.Controls.Add(this.btnConn7);
            this.Controls.Add(this.textDeviceSN7);
            this.Controls.Add(this.textConnStatus6);
            this.Controls.Add(this.btnBeep6);
            this.Controls.Add(this.btnConn6);
            this.Controls.Add(this.textDeviceSN6);
            this.Controls.Add(this.textConnStatus5);
            this.Controls.Add(this.btnBeep5);
            this.Controls.Add(this.btnConn5);
            this.Controls.Add(this.textDeviceSN5);
            this.Controls.Add(this.textConnStatus4);
            this.Controls.Add(this.btnBeep4);
            this.Controls.Add(this.btnConn4);
            this.Controls.Add(this.textDeviceSN4);
            this.Controls.Add(this.textConnStatus3);
            this.Controls.Add(this.btnBeep3);
            this.Controls.Add(this.btnConn3);
            this.Controls.Add(this.textDeviceSN3);
            this.Controls.Add(this.textConnStatus2);
            this.Controls.Add(this.btnBeep2);
            this.Controls.Add(this.btnConn2);
            this.Controls.Add(this.textDeviceSN2);
            this.Controls.Add(this.textConnStatus1);
            this.Controls.Add(this.btnBeep1);
            this.Controls.Add(this.btnConn1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textDeviceSN1);
            this.Controls.Add(this.tsRefreshDevice);
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FM1208";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Multi-device operation";
            this.Load += new System.EventHandler(this.Mifare_1K_Load);
            this.tsRefreshDevice.ResumeLayout(false);
            this.tsRefreshDevice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripButton tsbtnConnect;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStrip tsRefreshDevice;
        private System.Windows.Forms.TextBox textDeviceSN1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnConn1;
        private System.Windows.Forms.Button btnBeep1;
        private System.Windows.Forms.TextBox textConnStatus1;
        private System.Windows.Forms.TextBox textConnStatus2;
        private System.Windows.Forms.Button btnBeep2;
        private System.Windows.Forms.Button btnConn2;
        private System.Windows.Forms.TextBox textDeviceSN2;
        private System.Windows.Forms.TextBox textConnStatus3;
        private System.Windows.Forms.Button btnBeep3;
        private System.Windows.Forms.Button btnConn3;
        private System.Windows.Forms.TextBox textDeviceSN3;
        private System.Windows.Forms.TextBox textConnStatus4;
        private System.Windows.Forms.Button btnBeep4;
        private System.Windows.Forms.Button btnConn4;
        private System.Windows.Forms.TextBox textDeviceSN4;
        private System.Windows.Forms.TextBox textConnStatus5;
        private System.Windows.Forms.Button btnBeep5;
        private System.Windows.Forms.Button btnConn5;
        private System.Windows.Forms.TextBox textDeviceSN5;
        private System.Windows.Forms.TextBox textConnStatus6;
        private System.Windows.Forms.Button btnBeep6;
        private System.Windows.Forms.Button btnConn6;
        private System.Windows.Forms.TextBox textDeviceSN6;
        private System.Windows.Forms.TextBox textConnStatus7;
        private System.Windows.Forms.Button btnBeep7;
        private System.Windows.Forms.Button btnConn7;
        private System.Windows.Forms.TextBox textDeviceSN7;
        private System.Windows.Forms.TextBox textConnStatus8;
        private System.Windows.Forms.Button btnBeep8;
        private System.Windows.Forms.Button btnConn8;
        private System.Windows.Forms.TextBox textDeviceSN8;
    }
}

